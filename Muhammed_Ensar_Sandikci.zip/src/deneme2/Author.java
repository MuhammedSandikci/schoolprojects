package deneme2;

public class Author {
	String publisher;
	static String name;
	int birthDate;
	public Author(String name, String publisher, int birthDate ) {
		Author.name = name;
		this.publisher = publisher;
		this.birthDate = birthDate;
		
	}
	
	public String getPublisher() {
		return this.publisher;
	}
	public void setPublisher(String newPublisher) {
		this.publisher = newPublisher;
	}
	public String toString() {
		return "Author is: " + publisher;
	}
	public static void main(String[] args) {
		

	}

}
