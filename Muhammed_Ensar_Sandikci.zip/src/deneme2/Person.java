package deneme2;
public class Person {
	static String name;
	int birthDate;
	String birthPlace;

public Person(String name,int birthDate,String birthPlace) {
	Person.name = name;
	this.birthDate = birthDate;
	this.birthPlace = birthPlace;
}	
public Person(String name,int i) {
	Person.name = name;
	this.birthDate = i;
}
public Person(String name) {
	Person.name = name;
}
public String getname() {
	return Person.name;
}
public String toString() {
	return "Name: " + name + "Birth Date: " + birthDate + "Birth Place: " + birthPlace;
	
}
	public static void main(String[] args) {
		
	}

}
