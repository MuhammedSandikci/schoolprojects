package deneme2;

public class Book{
	int id;
	String title;
	Author author;
	boolean borrowed;

public Book(int id,String title,Author author1) {
	this.id = id;
	this.title = title;
	this.author = author1;
}
public Book(int id,String title) {
	this.id =id;
	this.title = title;
}
public void borrowed() {
	this.borrowed = true;
}

public void returned() {
	this.borrowed = false;
	
}
public boolean isBorrowed() {
	if (this.borrowed) {
		return true;
		
	}else {
		return false;
	}	
}

public String toString() {
	return	"Book ID is: " + id + " Book name is: " + title + " Author is: " + author;
}

public int getID() {
	return this.id;	
}
public void setID(int newID) {
	this.id = newID;
}
public String getTitle() {
	return this.title;
}
public void setTitle(String newTitle) {
	this.title = newTitle;
}

public Author getAuthor() {
	return this.author;
}
public void setAuthor(Author newAuthor) {
	this.author = newAuthor;
}

public static void main(String[] args) {
	

}


}
