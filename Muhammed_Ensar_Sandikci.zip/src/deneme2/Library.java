package deneme2;

import java.util.ArrayList;
import java.util.List;

public class Library {

	String adress;
	ArrayList<Book> Booklist;
	ArrayList<Customer> Customerlist;
	public ArrayList<Book>getBooks() {
		return Booklist;
	}
	public ArrayList<Customer>getCustomer() {
		return Customerlist;
	}
	public Library(String lib) {
			this.adress = lib;
			this.Booklist = new ArrayList<Book>();
			this.Customerlist = new ArrayList<Customer>();
	}
	
	public void addBook(Book book) {
		this.Booklist.add(book);
	}
	public static void OpeningHours() {
		System.out.println("Library hours: \n" + "Libraries are open daily from 9 am to 5 pm.");
	}
	public void printAddress(){
		System.out.println(this.adress);
	}
	public void borrowBook(String title,String name){
		for(Book book:this.Booklist){
			if(title.equals(book.title)){
				if(book.isBorrowed()){
					
					System.out.println("Sorry, this book is already borrowed");
					return;
				}
				else{
					book.borrowed();
			
					System.out.println(name +  " succesfully borrowed "+book.title);
					return;
				}
			}
		}
		System.out.println("Sorry, this book is not in our catalog");
	}
	public void printAvailableBooks(){
		if(this.Booklist.isEmpty()){
			System.out.println("The book isn't available in the catalog");
		}
		for(Book book:this.Booklist){
			System.out.println(book.getTitle());
		}
	}
	
	public void returnBook(String title){
		for(Book book:this.Booklist){
			if(title.equals(book.getTitle())){
				book.returned();
				System.out.println(Customer.name + " succesfully returned "+book.getTitle());
			}
		}
	}
	public static void getAddress1() {
	System.out.println("\nFirst Library Address:");
	String address1 = "10 Main St.";
	System.out.println(address1);
}
	public static void getAddress2() {
		System.out.println("\nSecond Library Address:");
		String address2 = "221B Baker St.";
		System.out.println(address2);
	}

	

	public static void main(String[] args) {
		OpeningHours();
		getAddress1();
		
		Library firstLibrary = new Library("10 Main St.");
		Library secondLibrary = new Library("221B Baker St.");
		List<String> BookList = new ArrayList<String>();
		BookList.add("The Da Vinci Code ");
		BookList.add("Le Petit Prince ");
		BookList.add("A Tale of Two Cities ");
		BookList.add("The Lord of the Rings ");
		BookList.add("The Lord of the Rings ");
		
		List<String> AuthorList = new ArrayList<String>();
		AuthorList.add("Dan Brown ");
		AuthorList.add("Antoine de Saint-Exupery ");
		AuthorList.add("Charles Dickens ");
		AuthorList.add("J. R. R. Tolkien ");
		AuthorList.add("J. R. R. Tolkien ");
		System.out.println("\nBooks in the first library: " );
		
		for (int i = 0 ; i < BookList.size(); i++) {
		    System.out.println("Book name is: "+BookList.get(i)+"Author name is: "+AuthorList.get(i));   
		}	
		
		List<String> CustomerList1 = new ArrayList<String>();
		System.out.println("Dictionary name is : " + Dictionary.TitleDict + "  Definitions: " + Dictionary.definitions);
		
		CustomerList1.add("\nName: Ayse Caliskan, Birth Date: 1995, Birth Place: Istanbul\n" + "Address: 10 Green Brier Blv.");
		CustomerList1.add("Name: Mehmet Ari, Birth Date: -, Birth Place: -\n" + "Address: 10 Liberty St.");
		CustomerList1.add("Name: Ela Kara, Birth Date: 1980, Birth Place: -\n" + "Address: 17 Main St.");
		CustomerList1.add("Name: Selin Ergul, Birth Date: 1987, Birth Place: -\n" + "Address: -");
		
		List<String> CustomerList2 = new ArrayList<String>();
		CustomerList2.add("Name: Ismail Celik, Birth Date: 1986, Birth Place: Antalya\n" + "Address: 18 Green Brier Blv.");
		CustomerList2.add("Name: Selin Ergul, Birth Date: 1987, Birth Place: -\n" + "Address: -");
		
		System.out.println("\nCustomers in the first library: ");
		for (int b = 0 ;  b< CustomerList1.size(); b++) {
		    System.out.println(CustomerList1.get(b));   
		}	
		getAddress2();
		System.out.println("\nBooks in the second library: ");
		List<String> BookList2 = new ArrayList<String>();
		
		if(BookList2.size()==0) {
			System.out.println("No book in catalog");
		}
		else {
			for (int i = 0 ; i < BookList2.size(); i++) {
			    System.out.println("Book name is: "+BookList2.get(i));   
			}	
		}
		System.out.println(BookList2);
		System.out.println("\nCustomers in the second library: ");
		for (int b = 0 ;  b< CustomerList2.size(); b++) {
		    System.out.println(CustomerList2.get(b));   
		}	
		Author author1 = new Author("Dan Brown", "Doubleday", 1964);
		Author author2 = new Author("Antoine de Saint-Exupery", "Gallimard", 1900);
		Author author3 = new Author("Charles Dickens", "Chapman & Hall", 1812);
		Author author4 = new Author("J. R. R. Tolkien", "George Allen & Unwin", 1892);

		firstLibrary.addBook(new Book(1, "The Da Vinci Code", author1));
		firstLibrary.addBook(new Book(2, "Le Petit Prince", author2));
		firstLibrary.addBook(new Book(3, "A Tale of Two Cities", author3));
		firstLibrary.addBook(new Book(4, "The Lord of the Rings", author4));
		firstLibrary.addBook(new Book(5, "The Lord of the Rings", author4));
		firstLibrary.addBook(new Dictionary(6, "Oxford Dictionary of English", 6000));

		firstLibrary.addCustomer(new Customer("Ayse Caliskan", "Istanbul", 1995, "10 Green Brier Blv."));
		firstLibrary.addCustomer(new Customer("Mehmet Ari", "-",0,"10 Liberty St."));
		firstLibrary.addCustomer(new Customer("Ela Kara", 1980, "17 Main St."));

		secondLibrary.addCustomer(new Customer("Ismail Celik", "Antalya", 1986, "18 Green Brier Blv."));
		secondLibrary.addCustomer (new Customer("Selin Ergul","-", 1987,"-"));


		System.out.println("\nBorrowing The Lord of the Rings by Ayse Caliskan from the first library:");
		firstLibrary.borrowBook("The Lord of the Rings", "Ayse Caliskan");
		System.out.println();

		System.out.println("Borrowing The Lord of the Rings by Mehmet Ari from the first library:");
		firstLibrary.borrowBook("The Lord of the Rings", "Mehmet Ari");
		System.out.println();

		System.out.println("Borrowing The Lord of the Rings by Ela Kara from the first library:");
		firstLibrary.borrowBook("The Lord of the Rings", "Ela Kara");
		System.out.println();

		System.out.println("Borrowing Le Petit Prince by Ayse Caliskan from the first library");
		firstLibrary.borrowBook("Le Petit Prince", "Ayse Caliskan");
		System.out.println();

		System.out.println("Borrowing A Tale of Two Cities by Emre Kiraz from the first library:");
		firstLibrary.borrowBook("A Tale of Two Cities", "Emre Kiraz");
		System.out.println();

		System.out.println("Borrowing Angels and Demons by Selin Ergul from the first library:");
		firstLibrary.borrowBook("Angels and Demons", "Selin Ergul");
		System.out.println();

		System.out.println("Borrowing Le Petit Prince by Ismail Celik from the second library:");
		secondLibrary.borrowBook("Le Petit Prince", "Ismail Celik");
		System.out.println();

		System.out.println("Books available in the first library:");
		firstLibrary.printAvailableBooks();
		System.out.println();
		System.out.println("Books available in the second library:");
		secondLibrary.printAvailableBooks();
		System.out.println();

		System.out.println("Returning the book which is borrowed by Ayse Caliskan to the first library:");
		firstLibrary.returnBook("Ayse Caliskan");
		System.out.println();

		System.out.println("Returning the book which is borrowed by Ismail Celik to the second library:");
		secondLibrary.returnBook("Ismail Celik");
		System.out.println();

		System.out.println("Returning the book which is borrowed by Mehmet Ari to the second library:");
		secondLibrary.returnBook("Mehmet Ari");
		System.out.println();

		System.out.println("Borrowing Le Petit Prince by Ayse Caliskan from the first library:");
		firstLibrary.borrowBook("Le Petit Prince", "Ayse Caliskan");
		System.out.println();

		System.out.println("Borrowing Le Petit Prince by Selin Ergul from the second library:");
		secondLibrary.borrowBook("The Lord of the Rings", "Selin Ergul");
		System.out.println();

		System.out.println("Borrowing The Lord of the Rings by Selin Ergul from the first library:");
		firstLibrary.borrowBook("The Lord of the Rings", "Selin Ergul");
		System.out.println();

		System.out.println("Books available in the first library:");
		firstLibrary.printAvailableBooks();
		
		
		
		
	}

	void addCustomer(Customer customer) {
		
		
	}
	
}




