package deneme2;

class Customer extends Person{
	String address;	
	boolean borrowABook;
	public Customer(String name,String birthPlace, int birthDate,String address) {
	super(name,birthDate,birthPlace);
	}
	public Customer(String name,int birthDate,String address) {
		super(name,birthDate);
	}
	public Customer(String name){
		super(name);
	}
	public Customer(String name,int i){
		super(name,i);
	}
	void addCustomer(Customer customer) {
		}
	public String getAddress() {
		return this.address;
	}
	public void setAddress(String newAddress) {
		this.address = newAddress;
	}
	public String toString() {
		return "Name: " + name + "Birth Date: " + birthDate + "Birth Place: " + birthPlace + "\nAddress: " + address;
	}
	public void setname(String newName) {
		Customer.name = newName;
	}
	public int getbirthDate() {
		return this.birthDate;
	}
	public void setbirthDate(int newbirthDate) {
		this.birthDate = newbirthDate;
	}
	public String getbirthPlace() {
		return this.birthPlace;
	}
	public void setbirthPlace(String newbirthPlace) {
		this.birthPlace = newbirthPlace;
	}
	public boolean getborrowABook() {
		return borrowABook;
	}
	public void setborrowedABook(boolean newborrowedABook) {
		this.borrowABook = newborrowedABook;
	}
	

	

	public static void main(String[] args) {
		

	}

}
