package deneme2;

class Dictionary extends Book{
	static String TitleDict = ("Oxford Dictionary of English");
	static int definitions = 6000;
	
public Dictionary(int id,String title,int definitions) {
	super(id, title);
	
}

public String toString() {
	
	return "Dictionary name is : " + TitleDict + "Definitions: " + definitions;
}
}
